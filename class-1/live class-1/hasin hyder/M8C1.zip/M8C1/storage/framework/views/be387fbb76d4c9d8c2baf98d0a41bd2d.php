<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Person</title>
</head>
<body>

    <h1>Created a new person with </h1>

    <h2>Name: <?php echo e($name); ?></h2>
    <h2>Email: <?php echo e($email); ?></h2>

    <?php if($image): ?>
    <h2>Image Name: <?php echo e($image); ?></h2>
    <img src="<?php echo e(asset('images/'.$image)); ?>" alt="image" width="600px" height="600px">
    <?php endif; ?>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\M8C1\resources\views/newperson.blade.php ENDPATH**/ ?>